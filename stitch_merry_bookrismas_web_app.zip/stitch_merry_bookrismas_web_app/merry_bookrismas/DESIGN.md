---
name: Merry Bookrismas
colors:
  surface: '#fff8f5'
  surface-dim: '#ffd1b6'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1ea'
  surface-container: '#ffeadf'
  surface-container-high: '#ffe3d3'
  surface-container-highest: '#ffdbc8'
  on-surface: '#2e1504'
  on-surface-variant: '#584140'
  inverse-surface: '#472915'
  inverse-on-surface: '#ffede5'
  outline: '#8b716f'
  outline-variant: '#dfbfbd'
  surface-tint: '#aa3433'
  primary: '#87191d'
  on-primary: '#ffffff'
  primary-container: '#a83232'
  on-primary-container: '#ffc9c5'
  inverse-primary: '#ffb3ae'
  secondary: '#436556'
  on-secondary: '#ffffff'
  secondary-container: '#c2e8d5'
  on-secondary-container: '#476a5a'
  tertiary: '#5c4000'
  on-tertiary: '#ffffff'
  tertiary-container: '#775715'
  on-tertiary-container: '#fbcf81'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad7'
  primary-fixed-dim: '#ffb3ae'
  on-primary-fixed: '#410004'
  on-primary-fixed-variant: '#891b1f'
  secondary-fixed: '#c5ebd7'
  secondary-fixed-dim: '#a9cfbc'
  on-secondary-fixed: '#002115'
  on-secondary-fixed-variant: '#2b4d3f'
  tertiary-fixed: '#ffdea8'
  tertiary-fixed-dim: '#ebc074'
  on-tertiary-fixed: '#271900'
  on-tertiary-fixed-variant: '#5e4200'
  background: '#fff8f5'
  on-background: '#2e1504'
  surface-variant: '#ffdbc8'
typography:
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  margin: 1.25rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system blends literary warmth with holiday festivity for a high school book club's interactive holiday trivia web application. 

### Brand Personality & Mood
- **Atmospheric Literary Salon:** Evokes a cozy winter library lined with polished wood bookshelves, warm parchment paper, and soft firelight.
- **Approachable Youth Elegance:** Sophisticated enough to avoid childish holiday tropes, yet intuitive, playful, and responsive for high school students engaging in competitive literary trivia.
- **Festive Nostalgia:** Celebratory, tactile, and comforting, balancing winter holiday joy with the quiet reverence of classic books.

### Visual Style
- **Warm Editorial Skeuomorphism:** Tactile and inviting. Surfaces utilize warm cream backgrounds, deeply radiused containers (`rounded-2xl` and `rounded-3xl`), and soft, tinted ambient drop shadows reminiscent of candlelight.
- **Accents & Motifs:** Elegant serif displays, delicate festive ornaments (star toppers, book ribbon dividers, evergreen sprigs), and rich tactile card treatments.

## Colors

The palette captures a classic Christmas reading parlor, avoiding neon or stark primary shades in favor of grounded, rich tones.

### Palette Hierarchy
- **Primary (`#A83232` - Christmas Red):** Primary CTA buttons, active state indicators, score callouts, and key festive highlights.
- **Secondary (`#244638` - Deep Forest Green):** Academic badges, secondary buttons, success/correct answer states, header backgrounds, and deep contrasting sections.
- **Tertiary (`#D5AC62` - Antique Gold):** Star ratings, celebration podiums (1st place), streak awards, and decorative foil trims.
- **Neutral Accent (`#68452F` - Wood Brown):** Text headings, borders, dividers, subtle button outlines, and warm structural framing.
- **Canvas Base (`#F5EBDD` - Warm Cream):** Default page backdrop reminiscent of aged book pages and cozy walls.
- **Surface Elevation (`#FFF9F0` - Warm Milk White):** Floating cards, modal backgrounds, and interactive input surfaces.

### Functional Usage
- **Text & Readability:** Never use stark `#000000`. Body text relies on deep roast brown (`#2E1E14`), ensuring high readability against `#FFF9F0` and `#F5EBDD` while preserving an organic, warm tone.
- **Answer Feedback:** Correct choices trigger Deep Forest Green (`#244638`) fills with Gold (`#D5AC62`) checkmark emblems. Incorrect choices trigger Christmas Red (`#A83232`) pulses.

## Typography

The type system pairs an expressive, high-contrast transitional serif (`Playfair Display`) with an approachable, clean geometric sans-serif (`Plus Jakarta Sans`, falling back smoothly to `Pretendard` or system Korean typefaces for Korean glyphs).

### Hierarchy & Pairing Rules
- **Display & Headlines:** Use `Playfair Display` for major titles, quiz stage transitions, leaderboard headers, and score totals. In Korean copy contexts, fallback automatically pairs with warm humanist serif/gothic glyphs.
- **Quiz Questions & Literary Excerpts:** Set in `headline-sm` or `body-lg` with generous line-height to guarantee high legibility under timed quiz conditions.
- **Body & Interactive Labels:** Use `Plus Jakarta Sans` for multiple-choice options, button labels, statistics, timers, and tooltips to maximize readability on mobile displays.

## Layout & Spacing

Designed as a mobile-first web app, the layout philosophy prioritizes single-hand mobile ergonomics, content centeredness, and breathable pacing.

### Layout Model
- **Mobile Foundation:** Strict maximum content constraint (`max-w-md` / 448px) centered on larger viewports, keeping the quiz focused and native-feeling.
- **Vertical Rhythm:** Generous spacing (`space-lg` to `space-xl`) between questions and action zones prevents accidental miss-taps during fast-paced quiz rounds.
- **Grid & Gutters:** A 4-column fluid layout on mobile viewports with `16px` (`1rem`) gutters and `20px` (`1.25rem`) screen edges. Expands to an 8-column layout on tablet viewports when displaying side-by-side leaderboard podiums.

## Elevation & Depth

Visual hierarchy uses warm, candlelit depth cues rather than synthetic cool grays.

### Surface Tiers
- **Layer 0 (Canvas):** Warm Cream (`#F5EBDD`) flat floor.
- **Layer 1 (Card & Quiz Slates):** Warm Milk White (`#FFF9F0`) surfaces equipped with a delicate 1px border of `rgba(104, 69, 47, 0.12)`.
- **Layer 2 (Elevated Sheets & Selected Cards):** Lifted with a diffuse warm amber drop shadow:
  - `0 8px 24px -4px rgba(104, 69, 47, 0.12), 0 2px 6px -1px rgba(104, 69, 47, 0.06)`
- **Layer 3 (Modals & Celebration Overlays):** Deep festive elevation with a backdrop scrim (`rgba(36, 70, 56, 0.45)` - deep pine tint) and rich gold-accented outer glow:
  - `0 20px 40px -8px rgba(46, 30, 20, 0.25), 0 0 0 1px rgba(213, 172, 98, 0.3)`

## Shapes

The geometric personality features soft, storybook curves that feel safe, touchable, and warm.

### Corner Radius System
- **Core Elements (`rounded-xl` / 16px):** Standard buttons, text input fields, countdown timers, and small item cards.
- **Containers & Trivia Cards (`rounded-2xl` to `rounded-3xl` / 20px - 24px):** Primary quiz question blocks, dialog modals, and podium stands.
- **Pill Accents (Full Round / 9999px):** Category badges, streak chips, and floating navigation bars.

## Components

### Buttons
- **Primary Action (Holiday Red):** Solid `#A83232` background with `#FFF9F0` text, subtle inner top bevel (`inset 0 1px 0 rgba(255,255,255,0.2)`), and an amber shadow on active press.
- **Secondary Action (Deep Pine):** `#244638` background with `#FFF9F0` text, used for secondary actions like "View Book Excerpt" or "Leaderboard".
- **Tertiary / Ghost:** Border of `1.5px solid rgba(104, 69, 47, 0.2)` over `#FFF9F0` background with Wood Brown text.

### Multiple-Choice Quiz Cards
- Base state: `#FFF9F0` background, subtle outline of `#68452F` at 12% opacity, `rounded-2xl` corners, with an index marker (A, B, C, D) in Antique Gold circle.
- Selected state: Thick 2px border in `#A83232` with a 5% tinted red fill.
- Correct state: `#244638` background, `#FFF9F0` text, with a `#D5AC62` star or checkmark icon.
- Incorrect state: `#A83232` background with a gentle horizontal shake animation.

### Chips & Badges
- Pill-shaped (`rounded-full`), padded with `0.25rem 0.75rem`.
- Genre / Club tags: Forest Green tint (`rgba(36, 70, 56, 0.1)`) with `#244638` text.
- Streak & Score tags: Antique Gold background (`#D5AC62`) with `#2E1E14` bold text and a subtle book-ribbon tail motif.

### Progress & Timers
- **Countdown Bar:** Pill rail in `#E6D6C2` with fill graduating from Antique Gold (`#D5AC62`) to Christmas Red (`#A83232`) as time elapses.
- **Stage Indicator:** Dot train decorated as small holiday baubles or evergreen wreaths representing question steps.

### Leaderboard Podium Card
- First-place block styled with a subtle Antique Gold foil border, a small crown/star ornament above the profile avatar, and a `#FFF9F0` parchment backdrop.