# 메리 북리스마스 (Merry Bookrismas)

Vanilla JS(ES Modules) + Firebase(Auth/Firestore/Storage) + Gemini + Vercel Serverless.

## 1. Firebase 설정
1. Firebase 콘솔 > 프로젝트 설정 > 내 앱(웹)의 값을 `firebase-config.js`에 입력합니다. (apiKey, projectId, storageBucket, messagingSenderId, appId — 이 값들은 공개되어도 되는 웹 설정입니다.)
2. Authentication > 로그인 방법에서 **Google**을 활성화합니다.
3. Authentication > 설정 > **승인된 도메인**에 Vercel 배포 도메인(예: `xxx.vercel.app`)을 추가합니다. (미등록 시 로그인 팝업이 `auth/unauthorized-domain`으로 실패합니다.)
4. Firestore를 만들고 `firestore.rules`를 배포합니다. (콘솔 > 규칙에 붙여넣기 또는 `firebase deploy --only firestore:rules`)
5. (선택) Storage를 활성화하고 `storageBucket`을 입력하면 프로필/표지 업로드가 동작합니다. 비워두면 업로드 시 "저장소 미설정" 오류를 표시합니다(성공으로 위장하지 않음). Storage 규칙 예시:
   `allow read: if request.auth != null; allow write: if request.auth != null && request.resource.size < 5*1024*1024 && request.resource.contentType.matches('image/.*');`

## 2. Vercel 환경변수 (Settings > Environment Variables)
| 이름 | 값 |
|---|---|
| `GEMINI_API_KEY` | Gemini API 키 (산타 AI, `api/generate.js`) |
| `FIREBASE_SERVICE_ACCOUNT` | Firebase 서비스 계정 JSON 전체 (점수 계산 `api/score.js`, 토큰 검증) |

## 3. 보안 구조
- 포인트/레이팅은 클라이언트가 수정할 수 없습니다. `api/score.js`가 Firebase ID 토큰을 검증하고 Admin SDK로 트랜잭션 처리합니다.
- 규칙: 정답 +문항 배점(기본 20)P, +200 레이팅 / 오답 포인트 0, -100 레이팅(0 미만 불가). 퀴즈당 1회, 문항당 1회만 반영됩니다.
- 정답·해설은 `quizzes/{id}/keys/answers`에만 있어 개발자와 서버만 읽을 수 있습니다.
- 개발자 계정(이메일 인증 필수)은 `firestore.rules`와 `firebase-config.js`의 두 곳에서 같은 목록을 사용합니다. 변경 시 두 곳을 함께 수정하세요.

## 4. 추가 자산
- 기본 이미지: `assets/images/` (default-cover/avatar/tree.svg). 서재 배경 사진은 CSS 그라데이션으로 대체되어 있으며 `style.css`의 `body[data-bg]`를 이미지로 바꾸면 됩니다.
- 음악/효과음: `assets/audio/bgm0.mp3~bgm2.mp3`, `correct.mp3`, `wrong.mp3`, `like.mp3`를 넣으면 재생됩니다.

## 5. 배포
`vercel` 또는 GitHub 연동으로 배포합니다. 로컬 확인은 `npx vercel dev`.
