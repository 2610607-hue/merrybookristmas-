import{initializeApp}from"https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import{getAuth,GoogleAuthProvider,signInWithPopup,onAuthStateChanged,signOut}from"https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import{getFirestore,doc,getDoc,setDoc,updateDoc,addDoc,deleteDoc,collection,getDocs,query,where,orderBy,limit,serverTimestamp,runTransaction,increment}from"https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import{getStorage,ref,uploadBytesResumable,getDownloadURL}from"https://www.gstatic.com/firebasejs/10.12.0/firebase-storage.js";
import{firebaseConfig as C,DEVELOPERS}from"./firebase-config.js";

/* ---------- 기본 ---------- */
const $=s=>document.querySelector(s),app=$('#app');
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const md=s=>esc(s).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/\n/g,'<br>');
const AV={산타:'🎅',루돌프:'🦌',난쟁이:'🧝',별:'⭐',눈사람:'⛄',종:'🔔',트리:'🎄',양말:'🧦',사탕:'🍭'};
const ORN={'황금 종':'🔔','선물상자':'🎁','양말':'🧦','북극성':'⭐','진저맨':'🍪'};
const BG=['포근한 벽난로 서재','별빛 창문과 설원','빈티지 앤틱 북카페','오로라 겨울 하늘'];
const GOALS=['📖 3권 완독하기','☕ 매주 1회 서평 쓰기','⭐ 퀴즈 랭킹 1위 도전'];
const TAGS=['유형문제','작품 이해','등장인물 분석','킬러문제','오답노트','독서토론'];
const DEF='assets/images/default-cover.svg';
const configured=!!(C.apiKey&&C.projectId&&C.appId);
let fb={},U=null,me=null,V='login',P={},memos={},quizzes={},draft={},D={},chat=[],qz={},wd={},busy=false;
if(configured){const a=initializeApp(C);fb={auth:getAuth(a),db:getFirestore(a),st:C.storageBucket?getStorage(a):null}}
const isDev=()=>!!U&&U.emailVerified&&DEVELOPERS.includes((U.email||'').trim().toLowerCase());
const avatar=u=>u?.photoURL?`<img src="${esc(u.photoURL)}" alt="">`:AV[u?.avatar]||'🎅';
const err=e=>{const c=e?.code||'';return c.includes('permission')?'권한이 없습니다.':c.includes('unavailable')||!navigator.onLine?'네트워크 연결을 확인해 주세요.':c==='auth/popup-closed-by-user'?'로그인 창이 닫혔어요. 다시 시도해 주세요.':c==='auth/unauthorized-domain'?'이 주소가 Firebase 승인된 도메인에 없어요. (README 참고)':(e?.message||'알 수 없는 오류가 발생했어요.')};
function toast(m,q){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),q?900:2600)}
const wrap=f=>async(...a)=>{try{return await f(...a)}catch(e){console.error(e);toast(err(e))}};
const modal=h=>{$('#modal').innerHTML=`<div class="ov" onclick="if(event.target===this)A.close()"><div class="sheet">${h}</div></div>`};
async function api(path,body){const t=await U.getIdToken(),r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+t},body:JSON.stringify(body)});const j=await r.json().catch(()=>({}));if(!r.ok)throw Error(j.error||'서버 오류가 발생했어요.');return j}
const refreshMe=async()=>{me=(await getDoc(doc(fb.db,'users',U.uid))).data()};
async function upload(file,path){
  if(!fb.st)throw Error('이미지 저장소가 설정되지 않았어요. firebase-config.js의 storageBucket을 확인해 주세요.');
  if(!file||!file.type.startsWith('image/')||file.size>5e6)throw Error('5MB 이하의 이미지 파일을 선택해 주세요.');
  const r=ref(fb.st,path),t=uploadBytesResumable(r,file);
  await new Promise((ok,no)=>t.on('state_changed',s=>toast(`업로드 중… ${Math.round(s.bytesTransferred/s.totalBytes*100)}%`,1),no,ok));
  return getDownloadURL(r);
}
const logDev=(action,title)=>addDoc(collection(fb.db,'developerLogs'),{uid:U.uid,email:U.email,action,title,createdAt:serverTimestamp()}).catch(()=>{});

/* ---------- 설정 / 눈 / 음악 ---------- */
let set={theme:'system',snow:true,bg:0,bgm:true,bgmVol:.45,sfx:true,sfxVol:.6,track:0,...JSON.parse(localStorage.ms||'{}')};
let raf,started=false,bg;
function snow(on){const c=$('#snow'),x=c.getContext('2d');cancelAnimationFrame(raf);c.width=innerWidth;c.height=innerHeight;x.clearRect(0,0,c.width,c.height);c.style.display=on?'block':'none';if(!on)return;
  const f=Array.from({length:60},()=>({x:Math.random()*c.width,y:Math.random()*c.height,r:1+Math.random()*2.5,v:.4+Math.random()}));
  (function t(){x.clearRect(0,0,c.width,c.height);x.fillStyle='#fff';x.shadowColor='rgba(104,69,47,.45)';x.shadowBlur=4;for(const p of f){p.y+=p.v;p.x+=Math.sin(p.y/40)*.4;if(p.y>c.height){p.y=-5;p.x=Math.random()*c.width}x.beginPath();x.arc(p.x,p.y,p.r,0,7);x.fill()}raf=requestAnimationFrame(t)})()}
function bgm(){if(!set.bgm||!started){bg?.pause();return}bg??=new Audio();const s=`assets/audio/bgm${set.track}.mp3`;if(!bg.src.endsWith(s))bg.src=s;bg.loop=true;bg.volume=set.bgmVol;bg.play().catch(()=>{})}
const sfx=n=>{if(!set.sfx)return;const a=new Audio(`assets/audio/${n}.mp3`);a.volume=set.sfxVol;a.play().catch(()=>{})};
function apply(){document.body.classList.toggle('dark',set.theme==='dark'||(set.theme==='system'&&matchMedia('(prefers-color-scheme:dark)').matches));document.body.dataset.bg=set.bg;snow(set.snow);bgm()}
function saveSet(){localStorage.ms=JSON.stringify(set);apply();if(U&&me)updateDoc(doc(fb.db,'users',U.uid),{settings:set}).catch(()=>{})}
addEventListener('pointerdown',()=>{if(!started){started=true;bgm()}},{once:true});
matchMedia('(prefers-color-scheme:dark)').addEventListener('change',apply);

/* ---------- 데이터 ---------- */
async function loadMemos(){const s=await getDocs(query(collection(fb.db,'treeMemos'),where('public','==',true),limit(60)));memos={};const L=s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds??1e12)-(a.createdAt?.seconds??1e12));L.forEach(m=>memos[m.id]=m);return L}
async function loadQuizzes(){const s=await getDocs(query(collection(fb.db,'quizzes'),where('status','==','published')));quizzes={};s.forEach(d=>quizzes[d.id]={id:d.id,...d.data()});return Object.values(quizzes)}
const stars=n=>'⭐'.repeat(n||1);
const empty=t=>`<div class="card" style="text-align:center">${t}</div>`;

/* ---------- 화면 ---------- */
const NAV=[['settings','⚙️','설정'],['home','🎄','홈'],['quizzes','📖','독서 퀴즈'],['ranking','🏆','랭킹']];
const DNAV=[['devDash','▦','대시보드'],['devStudio','✏️','퀴즈 제작'],['devManage','📚','도서 관리'],['home','🏠','서재']];
function shell(h){
  if(V==='login'||V==='profile')return`<main>${h}</main>`;
  const dv=V.startsWith('dev'),act=['quiz','result'].includes(V)?'quizzes':['tree','santa'].includes(V)?'home':V;
  return`<header><b>🎄 메리 북리스마스${dv?' <span class="tag">DEV</span>':''}</b><span class="pill" id="pp">⭐ ${me?.points??0}P</span><span class="av" onclick="A.go('settings')">${avatar(me)}</span></header><main>${h}</main><nav>${(dv?DNAV:NAV).map(([k,i,t])=>`<a class="${k===act?'on':''}" onclick="A.go('${k}')"><i>${i}</i>${t}</a>`).join('')}</nav>`}
async function go(v,p={}){
  if(!U&&v!=='login')v='login';V=v;P=p;app.innerHTML=shell('<div class="card load">불러오는 중…</div>');
  try{if(v.startsWith('dev')&&!isDev())throw Error('개발자 권한이 없습니다.');app.innerHTML=shell(await views[v]());scrollTo(0,0)}
  catch(e){console.error(e);app.innerHTML=shell(`<div class="card">⚠️ ${esc(err(e))}<br><br><button class="btn" onclick="A.go('${v==='login'?'login':'home'}')">돌아가기</button></div>`)}
}
const views={};

views.login=async()=>`<div class="login"><div class="logo">📖</div><span class="chip g">❄️ 겨울 북살롱 시즌</span><h1 style="font-size:34px">메리 북리스마스</h1><p class="it">Merry Bookrismas</p><p>겨울밤, 책과 함께 따뜻해지는<br>우리들의 크리스마스 독서 살롱</p>
<div class="card"><h2>반가워요, 책 친구님! 🎄</h2><p class="note">독서퀴즈와 북클럽 회원을 위한 프라이빗 살롱입니다.</p>
${configured?`<button class="btn g" onclick="A.login()"><b style="color:#4285f4">G</b> Google 계정으로 시작하기</button><p class="note">학교 구글 계정(@sw.hs.kr) 또는 개인 Google 계정으로 입장하세요.</p>`:`<p>⚠️ Firebase 설정이 비어 있어요.<br><code>firebase-config.js</code>에 웹 앱 설정값을 입력해 주세요.</p>`}</div>
<div class="card"><i>“어떤 책은 맛만 보고, 어떤 책은 삼키며, 어떤 책은 씹어서 소화해야 한다.”</i><br><small>— 프랜시스 베이컨</small></div></div>`;

views.profile=async()=>{
  if(!P.keep)draft={nick:me?.nickname||'',avatar:me?.avatar||'산타',photoURL:me?.photoURL||'',goal:me?.goal||''};
  return`${me?`<button class="back" onclick="A.go('settings')">‹ 설정</button>`:''}<h2>${me?'프로필 수정':'북살롱에서 사용할 프로필을 꾸며보세요 🎄'}</h2><p class="note">닉네임과 아바타는 랭킹과 트리 메모에 표시돼요.</p>
<div class="card" style="text-align:center"><div class="bigav" id="bigav">${draft.photoURL?`<img src="${esc(draft.photoURL)}">`:AV[draft.avatar]}</div>
<input type="file" id="pf" accept="image/*" hidden onchange="A.photo(this.files[0])"><button class="btn gh" onclick="$('#pf').click()">📷 내 사진 업로드</button>${draft.photoURL?`<button class="back" style="margin-top:8px" onclick="A.nophoto()">사진 지우고 캐릭터 사용</button>`:''}</div>
<h3>크리스마스 캐릭터 아바타</h3><div class="grid">${Object.entries(AV).map(([n,e])=>`<button class="${n===draft.avatar&&!draft.photoURL?'on':''}" onclick="A.av('${n}')"><span>${e}</span>${n}</button>`).join('')}</div>
<label style="margin-top:16px">닉네임 <span id="nc">${draft.nick.length} / 12</span></label><input id="nick" maxlength="12" value="${esc(draft.nick)}" placeholder="살롱에서 불릴 이름" oninput="draft_nick(this.value)">
<label>나의 올겨울 독서 다짐 <small>선택</small></label><div class="scroll" style="flex-wrap:wrap">${GOALS.map(g=>`<button class="chip ${g===draft.goal?'g':''}" onclick="A.goal(this.textContent)">${g}</button>`).join('')}</div>
<button class="btn" style="margin-top:20px" onclick="A.saveProfile()">${me?'저장하기':'메리 북리스마스 시작하기 🎉'}</button>`};

views.home=async()=>{
  const[ms,qs]=await Promise.all([loadMemos(),loadQuizzes()]),q=qs[0];
  return`<section class="card tree"><div class="row"><span class="chip">🎄 오너먼트 ${ms.length}개</span><button class="chip g" onclick="A.go('tree')">🔍 트리 크게보기</button></div>
<div class="orns">${ms.slice(0,12).map(m=>`<button class="orn" onclick="A.memo('${m.id}')"><span>${ORN[m.ornament]||'🔔'}</span><small>${esc(m.title)}</small></button>`).join('')||'<p class="note">아직 걸린 메모가 없어요. 첫 오너먼트를 걸어보세요!</p>'}</div>
<button class="btn" onclick="A.write()">📝 트리에 메모 걸기</button></section>
<section class="card" style="background:var(--tint)"><div class="row top"><span style="font-size:44px">🎅</span><div><h3>산타클로스의 서재 대화</h3><p class="note">겨울 마음에 촛불을 켜줄 책을 찾고 있나요? 읽고 싶은 장르나 현재 고민을 편하게 들려주세요.</p></div></div><button class="btn gr" onclick="A.go('santa')">💬 산타와 1:1 도서 대화 시작하기</button></section>
${q?`<section class="card"><span class="chip">오늘의 살롱 퀴즈</span><div class="row top" style="margin-top:10px"><img class="cover" src="${esc(q.coverUrl||DEF)}" alt=""><div><small>${esc(q.author)}</small><h3>&lt;${esc(q.bookTitle)}&gt;</h3><p class="clip">${esc(q.description)}</p></div></div><button class="btn" onclick="A.go('quiz',{id:'${q.id}'})">▶ 오늘의 퀴즈 도전하기</button></section>`:empty('아직 공개된 퀴즈가 없어요.')}
<div class="row"><div class="card" style="flex:1"><small>나의 레이팅</small><h3>${me.rating}</h3></div><div class="card" style="flex:1"><small>완료한 퀴즈</small><h3>${me.quizzesDone||0}권</h3></div></div>`};

views.tree=async()=>{const ms=await loadMemos();
  return`<div class="row"><button class="back" onclick="A.go('home')">‹ 서재 홈으로</button><span class="chip">🌲 몰입 모드</span></div><h2 style="text-align:center">겨울밤, 트리에 맺힌 문장들</h2><p class="note" style="text-align:center">부원들이 달아둔 ${ms.length}개의 크리스마스 독서 오너먼트</p>
${ms.map((m,i)=>`<div class="card ${i%2?'fall':''}" onclick="A.memo('${m.id}')" style="cursor:pointer"><span class="chip">${ORN[m.ornament]||'🔔'} ${esc(m.ornament)}</span> <small>❤️ ${m.likes||0}</small><h3 style="font-size:18px">“${esc(m.title)}”</h3><small>${m.bookTitle?`《${esc(m.bookTitle)}》 · `:''}${esc(m.nickname)} · 터치하여 읽기 →</small></div>`).join('')||empty('아직 메모가 없어요.')}
<button class="btn" onclick="A.write()">✨ 나도 트리에 메모 걸기 (+30P)</button>`};

views.santa=async()=>{await loadQuizzes();const s=await getDoc(doc(fb.db,'santaChats',U.uid));chat=s.exists()?s.data().messages||[]:[];
  return`<div class="row"><button class="back" onclick="A.go('home')">‹ 서재로 돌아가기</button><button class="back" onclick="A.reset()">↻ 새 대화</button></div>
<div class="card row top"><span style="font-size:40px">🎅</span><div><h3 style="margin:0">AI 산타의 문학 살롱</h3><span class="chip g">Gemini</span><label style="margin-top:8px">대화 도서</label><select id="sb"><option value="">자유 대화</option>${Object.values(quizzes).map(q=>`<option ${P.book===q.bookTitle?'selected':''}>${esc(q.bookTitle)}</option>`)}</select></div></div>
<div id="chat">${(chat.length?chat:[{role:'model',text:'호호호! 책을 사랑하는 벗이여, 반갑구나. 오늘 밤 마음에 품은 문장이나 등장인물의 고민이 있니? 편하게 털어놓으렴.'}]).map(bub).join('')}</div>
<div class="scroll">${['마음 따뜻한 소설 추천','방학에 읽을 고전 명작','줄거리를 쉽게 설명해줘'].map(t=>`<button class="chip" onclick="A.ask(this.textContent)">${t}</button>`).join('')}</div>
<div class="inp"><input id="si" placeholder="산타 할아버지께 책에 대해 물어보세요" onkeydown="if(event.key==='Enter')A.ask()"><button class="btn sm" onclick="A.ask()">➤</button></div>`};
const bub=m=>`<div class="bub ${m.role==='user'?'u':''}">${md(m.text)}</div>`;

views.quizzes=async()=>{
  const[L,s]=await Promise.all([loadQuizzes(),getDocs(query(collection(fb.db,'quizAttempts'),where('uid','==',U.uid)))]);const at={};s.forEach(d=>at[d.data().quizId]=d.data());
  return`<h2>🎄 겨울 서재의 문학 퀴즈</h2><p class="note">총 ${L.length}편 입고 · 문학 작품 속 숨은 의미를 발견해 보세요.</p>
${L.map(q=>{const n=q.questions.length,d=Object.keys(at[q.id]?.answers||{}).length,pts=q.questions.reduce((s,x)=>s+(x.pts||20),0);
return`<article class="card"><div class="row top"><img class="cover" src="${esc(q.coverUrl||DEF)}" alt=""><div style="flex:1"><small>${esc(q.author)}</small><h3 style="margin:0">${esc(q.bookTitle)}</h3><p class="clip">${esc(q.description)}</p><small>난이도 ${stars(q.difficulty)} · 완료율 ${Math.round(d/n*100)}%</small><div class="bar"><i style="width:${d/n*100}%"></i></div></div></div>
<div class="row"><small>❓ ${n}문항 · 최대 +${pts}P</small><button class="btn sm" onclick="A.go('${d>=n?'result':'quiz'}',{id:'${q.id}'})">${d>=n?'결과 보기':d?'이어서 풀기':'퀴즈 도전하기'}</button></div></article>`}).join('')||empty('공개된 퀴즈가 아직 없어요.')}
<div class="card" style="background:var(--tint)"><h3>북리스마스 살롱 리그 규칙</h3><p>✅ 정답: <b>+20P</b>(문항 배점) · 레이팅 <b>+200</b><br>❌ 오답: 포인트 감점 없음 · 레이팅 <b>-100</b></p><small>문제당 제한 시간은 없어요. 퀴즈는 한 번만 점수에 반영돼요.</small></div>`};

const qview=(q,i)=>{qz={q,i};const x=q.questions[i],n=q.questions.length;
  return`<div class="row"><button class="back" onclick="A.go('quizzes')">‹ 퀴즈 서재로</button><span class="chip g">Q${i+1} / ${n}</span></div><div class="bar"><i style="width:${i/n*100}%"></i></div><span class="chip">${esc(q.bookTitle)}</span>
<div class="card quote">${x.excerpt?`<i>“${esc(x.excerpt)}”</i>`:''}<p><b>${esc(x.prompt)}</b></p></div><div id="opts">${x.options.map((o,k)=>`<button class="opt" onclick="A.pick(${k})"><span>${'ABCDE'[k]}</span>${esc(o)}</button>`).join('')}</div><div id="fb"></div>`};
views.quiz=async()=>{const q=quizzes[P.id]||(await loadQuizzes(),quizzes[P.id]);if(!q)throw Error('퀴즈를 찾을 수 없어요.');
  const a=await getDoc(doc(fb.db,'quizAttempts',U.uid+'_'+q.id)),d=a.exists()?Object.keys(a.data().answers||{}).length:0;
  if(d>=q.questions.length){V='result';return views.result()}return qview(q,d)};

views.result=async()=>{await refreshMe();const q=quizzes[P.id]||(await loadQuizzes(),quizzes[P.id]);const s=await getDoc(doc(fb.db,'quizAttempts',U.uid+'_'+P.id));if(!q||!s.exists())throw Error('풀이 기록이 없어요.');
  const a=s.data(),n=q.questions.length,t=a.completedAt&&a.startedAt?a.completedAt.seconds-a.startedAt.seconds:null,ch=a.ratingChange;
  return`<div class="card" style="background:var(--red);color:#fff9f0;text-align:center"><small style="color:#ffc9c5">HOLIDAY QUIZ COMPLETE</small><h2 style="color:#fff9f0">${a.correctCount===n?'축하합니다! 완벽한 사유의 여정':'퀴즈 완료! 수고했어요'}</h2>《${esc(q.bookTitle)}》</div>
<div class="row"><div class="card" style="flex:1"><small>정답 개수 · 정답률</small><h3>${a.correctCount}/${n} <small>${Math.round(a.correctCount/n*100)}%</small></h3></div><div class="card" style="flex:1"><small>획득 포인트</small><h3>+${a.earnedPoints}P</h3></div></div>
<div class="card"><small>풀이 시간: ${t==null?'-':`${String(t/60|0).padStart(2,'0')}:${String(t%60).padStart(2,'0')}`}</small><p>레이팅 변동 <b>${ch>=0?'+':''}${ch}</b> → 누적 레이팅 <b>${me.rating}</b></p></div>
<h3>문항별 정답 · 해설</h3>${q.questions.map((x,i)=>{const r=a.answers[i];return`<details class="card"><summary><b>Q${i+1}</b> ${r.correct?'✅ 정답':'❌ 오답'} (${r.rating>=0?'+':''}${r.rating})</summary><p>${esc(x.prompt)}</p><p>내 답: ${'ABCDE'[r.choice]}. ${esc(x.options[r.choice])}<br>정답: ${'ABCDE'[r.answer]}. ${esc(x.options[r.answer])}</p><p class="note">${md(r.explain)}</p></details>`}).join('')}
<button class="btn" onclick="A.go('home')">🎄 홈으로 돌아가기</button><div class="row" style="margin-top:10px"><button class="btn gh" onclick="A.go('santa',{book:'${esc(q.bookTitle).replace(/'/g,"\\'")}'})">🎅 산타와 대화</button><button class="btn gh" onclick="A.go('ranking')">🏆 명예의 전당</button></div>`};

views.ranking=async()=>{
  const s=await getDocs(query(collection(fb.db,'users'),orderBy('rating','desc'),limit(50))),L=s.docs.map((d,i)=>({id:d.id,...d.data(),rank:i+1})),mine=L.find(x=>x.id===U.uid),t=L.slice(0,3);
  const pod=(u,c)=>u?`<div class="p${c}"><div class="av" style="margin:auto;width:54px;height:54px;font-size:30px">${avatar(u)}</div><b>${esc(u.nickname)}</b><br><small>${u.rating}</small><div class="st">${['','I','II','III'][c]}</div></div>`:'<div></div>';
  return`<div class="row"><button class="back" onclick="A.go('quizzes')">‹ 독서 퀴즈</button></div><h2 style="text-align:center">홀리데이 명예의 전당 ✨</h2>
<div class="podium">${pod(t[1],2)}${pod(t[0],1)}${pod(t[2],3)}</div>
<div class="card" style="background:var(--red);color:#fff9f0"><small style="color:#ffc9c5">나의 살롱 랭킹</small><div class="row"><b>${mine?mine.rank+'위':'50위권 밖'} · ${esc(me.nickname)}</b><b>${me.rating}</b></div></div>
<h3>전체 랭킹 보드</h3>${L.slice(3).map(u=>`<div class="rk ${u.id===U.uid?'me':''}"><b>${u.rank}</b><span class="av">${avatar(u)}</span><div style="flex:1"><b>${esc(u.nickname)}</b><br><small>완료한 퀴즈 ${u.quizzesDone||0}편</small></div><b>${u.rating}</b></div>`).join('')||empty('아직 순위가 없어요.')}`};

views.settings=async()=>{const sw=(k,fn)=>`<span class="sw"><input type="checkbox" ${set[k]?'checked':''} onchange="A.set('${k}',this.checked)"></span>`;
  return`<h2>겨울밤 서재 설정</h2>
<div class="card"><label>화면 테마</label><select onchange="A.set('theme',this.value)">${[['system','기기 설정 따르기'],['light','라이트 모드'],['dark','다크 모드']].map(([v,t])=>`<option value="${v}" ${set.theme===v?'selected':''}>${t}</option>`).join('')}</select>
<div class="row"><span>❄️ 눈 내리기 효과</span>${sw('snow')}</div></div>
<div class="card"><h3>🎵 소리</h3><div class="row"><span>배경음악</span>${sw('bgm')}</div><select onchange="A.set('track',+this.value)">${['잔잔한 캐럴','벽난로 피아노','눈 내리는 밤'].map((t,i)=>`<option value="${i}" ${set.track===i?'selected':''}>${t}</option>`).join('')}</select><label>배경음악 볼륨</label><input type="range" min="0" max="1" step=".05" value="${set.bgmVol}" oninput="A.set('bgmVol',+this.value)">
<div class="row"><span>효과음</span>${sw('sfx')}</div><label>효과음 볼륨</label><input type="range" min="0" max="1" step=".05" value="${set.sfxVol}" oninput="A.set('sfxVol',+this.value)"><small>음악 파일은 assets/audio/ 에 추가하면 재생돼요.</small></div>
<div class="card"><h3>서재 배경 테마</h3>${BG.map((t,i)=>`<div class="theme ${set.bg===i?'on':''}" onclick="A.set('bg',${i})"><b>${i+1}.</b> ${t} ${set.bg===i?'✔':''}</div>`).join('')}</div>
<div class="card"><h3>프로필</h3><div class="row"><span class="av">${avatar(me)}</span><div style="flex:1"><b>${esc(me.nickname)}</b><br><small>${esc(me.goal||'독서 다짐 없음')}</small></div><button class="btn sm gh" onclick="A.go('profile',{})">수정</button></div></div>
${isDev()?`<div class="card" style="background:var(--tint)" onclick="A.go('devDash')"><b>🛠 개발자 모드 (Quiz Studio)</b><br><small>${esc(U.email)}</small></div>`:''}
<button class="btn gh" onclick="A.logout()">로그아웃</button>`};

/* ---------- 개발자 ---------- */
views.devDash=async()=>{
  const[qs,as,ls]=await Promise.all([getDocs(collection(fb.db,'quizzes')),getDocs(query(collection(fb.db,'quizAttempts'),limit(500))),getDocs(query(collection(fb.db,'developerLogs'),orderBy('createdAt','desc'),limit(5)))]);
  const Q=qs.docs.map(d=>({id:d.id,...d.data()})),pub=Q.filter(q=>q.status==='published'),dr=Q.filter(q=>q.status!=='published'),n=Q.reduce((s,q)=>s+(q.count||0),0);
  return`<div class="card" style="background:var(--tint)"><b>🛡 개발자 모드 활성화</b><br><small>${esc(U.email)} · 권한은 Firestore 규칙으로도 보호돼요.</small></div>
<div class="row"><div class="card" style="flex:1"><small>등록된 도서</small><h3>${Q.length}권</h3></div><div class="card" style="flex:1"><small>전체 퀴즈 문항</small><h3>${n}문항</h3></div></div>
<div class="row"><div class="card" style="flex:1"><small>공개 퀴즈</small><h3>${pub.length}권</h3></div><div class="card" style="flex:1"><small>임시 저장</small><h3>${dr.length}건</h3></div></div>
<button class="btn" onclick="A.go('devStudio',{})">＋ 새 퀴즈 만들기</button><div class="row" style="margin:10px 0"><button class="btn gr" onclick="A.go('devManage')">기존 퀴즈 관리</button><button class="btn gh" onclick="A.go('devManage',{tab:'draft'})">초안함 (${dr.length})</button></div>
<div class="card"><h3>학생 풀이 현황</h3><p>누적 풀이 기록 <b>${as.size}</b>건 · 완료 <b>${as.docs.filter(d=>d.data().completedAt).length}</b>건</p></div>
<div class="card"><h3>최근 등록·수정 로그</h3>${ls.docs.map(d=>{const l=d.data();return`<p>• ${esc(l.title)} — ${esc(l.action)}<br><small>${esc(l.email)} · ${l.createdAt?new Date(l.createdAt.seconds*1e3).toLocaleString('ko'):'방금'}</small></p>`}).join('')||'<small>아직 로그가 없어요.</small>'}</div>`};

views.devManage=async()=>{const s=await getDocs(collection(fb.db,'quizzes')),all=s.docs.map(d=>({id:d.id,...d.data()})),tab=P.tab||'all',L=all.filter(q=>tab==='all'||(tab==='published')===(q.status==='published'));quizzes={};all.forEach(q=>quizzes[q.id]=q);
  return`<div class="row"><h2>📚 도서 퀴즈 관리</h2><button class="btn sm" onclick="A.go('devStudio',{})">＋ 새 퀴즈</button></div><p class="note">총 ${all.length}권의 퀴즈가 서재에 있어요.</p>
<div class="row">${[['all','전체'],['published','공개중'],['draft','임시저장']].map(([k,t])=>`<button class="chip ${tab===k?'g':''}" onclick="A.go('devManage',{tab:'${k}'})">${t}</button>`).join('')}</div>
${L.map(q=>`<div class="card"><div class="row top"><img class="cover" style="width:56px;height:80px" src="${esc(q.coverUrl||DEF)}" alt=""><div style="flex:1"><h3 style="margin:0">${esc(q.bookTitle)||'(제목 없음)'}</h3><small>${esc(q.author)} · ${q.count||0}문항 · ${stars(q.difficulty)}</small><br><span class="chip ${q.status==='published'?'g':''}">${q.status==='published'?'학생 공개 중':'임시 저장 (비공개)'}</span></div><span class="sw"><input type="checkbox" ${q.status==='published'?'checked':''} onchange="A.tog('${q.id}',this.checked)"></span></div>
<div class="row" style="margin-top:10px"><button class="chip" onclick="A.go('devStudio',{id:'${q.id}'})">퀴즈 수정</button><button class="chip" onclick="A.go('devStudio',{id:'${q.id}',add:1})">문제 추가</button><button class="chip" onclick="A.prevSaved('${q.id}')">미리보기</button><button class="chip" style="color:#ba1a1a" onclick="A.del('${q.id}')">삭제</button></div></div>`).join('')||empty('해당하는 퀴즈가 없어요.')}
<div class="card" style="background:var(--tint)"><small>🛡 삭제하면 해당 퀴즈의 학생 풀이 기록과 통계도 함께 영구 삭제돼요. (이미 지급된 포인트·레이팅은 유지) 삭제 전 확인창에서 도서 제목을 입력해야 해요.</small></div>`};

const blank=()=>({prompt:'',excerpt:'',o:['','','','',''],a:-1,pts:20,explain:''});
const qblock=(x,i)=>`<div class="card"><div class="row"><h3 style="margin:0">${i+1}. 문항 작성</h3>${D.q.length>1?`<button class="chip" style="color:#ba1a1a" onclick="A.rmq(${i})">삭제</button>`:''}</div>
<label>문제 지문 <small>${x.prompt.length}/200</small></label><textarea maxlength="200" oninput="A.s('q.${i}.prompt',this.value)">${esc(x.prompt)}</textarea>
<label>문학 본문 인용구</label><textarea oninput="A.s('q.${i}.excerpt',this.value)">${esc(x.excerpt)}</textarea>
<label>5지선다 (정답 1개 선택)</label>${x.o.map((o,k)=>`<div class="row"><input type="radio" name="a${i}" ${x.a===k?'checked':''} onchange="A.s('q.${i}.a',${k})"><b>${'ABCDE'[k]}</b><input value="${esc(o)}" oninput="A.s('q.${i}.o.${k}',this.value)"></div>`).join('')}
<label>배점 (정답 시 포인트)</label><input type="number" min="1" max="100" value="${x.pts}" oninput="A.s('q.${i}.pts',+this.value||20)"><label>정답 상세 해설</label><textarea oninput="A.s('q.${i}.explain',this.value)">${esc(x.explain)}</textarea></div>`;
views.devStudio=async()=>{
  if(P.id&&!P.keep){const[q,k]=await Promise.all([getDoc(doc(fb.db,'quizzes',P.id)),getDoc(doc(fb.db,'quizzes',P.id,'keys','answers'))]);const d=q.data(),ks=k.exists()?k.data().answers:[];
    D={id:P.id,status:d.status,book:d.bookTitle,author:d.author,trans:d.translator||'',isbn:d.isbn||'',desc:d.description||'',cover:d.coverUrl||'',title:d.title||'',diff:d.difficulty||1,aud:d.audience||'all',tags:d.tags||[],q:d.questions.map((x,i)=>({prompt:x.prompt,excerpt:x.excerpt||'',o:x.options,a:ks[i]?.a??-1,pts:x.pts||20,explain:ks[i]?.explain||''}))};if(P.add)D.q.push(blank())}
  else if(!P.id&&!P.keep)D={status:'draft',book:'',author:'',trans:'',isbn:'',desc:'',cover:'',title:'',diff:1,aud:'all',tags:['유형문제'],q:[blank()]};
  const f=(l,k,t='text')=>`<label>${l}</label><input type="${t}" value="${esc(D[k])}" oninput="A.s('${k}',this.value)">`;
  return`<h2>✏️ Quiz Studio</h2><span class="chip ${D.status==='published'?'g':''}">${D.status==='published'?'공개 중':'임시 저장 (비공개)'}</span>
<div class="card"><h3>1. 책 정보</h3>${f('도서 제목','book')}${f('작가','author')}${f('역자','trans')}${f('ISBN','isbn')}<label>도서 설명</label><textarea oninput="A.s('desc',this.value)">${esc(D.desc)}</textarea>
<label>도서 표지 이미지</label><div class="row"><img class="cover" style="width:56px;height:80px" src="${esc(D.cover||DEF)}" alt=""><input type="file" accept="image/*" onchange="A.cover(this.files[0])"></div>${f('퀴즈 팩 제목','title')}
<label>난이도</label><select onchange="A.s('diff',+this.value)">${[1,2,3,4,5].map(n=>`<option value="${n}" ${D.diff===n?'selected':''}>${stars(n)}</option>`).join('')}</select>
<label>공개 대상</label><select onchange="A.s('aud',this.value)">${[['all','전체 학생'],['club','독서동아리'],['grade','학년별']].map(([v,t])=>`<option value="${v}" ${D.aud===v?'selected':''}>${t}</option>`).join('')}</select></div>
${D.q.map(qblock).join('')}<button class="btn gh" onclick="A.addq()">＋ 문항 추가 (현재 ${D.q.length}문항)</button>
<div class="card"><h3>3. 분류 · 태그</h3><div class="scroll" style="flex-wrap:wrap">${[...new Set([...TAGS,...D.tags])].map(t=>`<button class="chip ${D.tags.includes(t)?'g':''}" onclick="A.tag(this.textContent)">${D.tags.includes(t)?'✓ ':''}${esc(t)}</button>`).join('')}</div><div class="inp"><input id="nt" placeholder="새 태그 추가"><button class="btn sm gh" onclick="A.newtag()">추가</button></div></div>
<div class="row"><button class="btn gh" onclick="A.saveQ('draft')">임시저장</button><button class="btn gr" onclick="A.prevDraft()">학생 뷰 미리보기</button></div><button class="btn" style="margin-top:10px" onclick="A.askPub()">🚀 최종 공개</button>`};

/* ---------- 액션 ---------- */
const prevHTML=(t,qs)=>`<h2>미리보기: ${esc(t)}</h2>${qs.map((x,i)=>`<div class="card"><b>Q${i+1}. ${esc(x.prompt)}</b>${x.excerpt?`<p><i>“${esc(x.excerpt)}”</i></p>`:''}${x.o.map((o,k)=>`<p style="${x.a===k?'font-weight:700;color:var(--green)':''}">${'ABCDE'[k]}. ${esc(o)}${x.a===k?' ✔ 정답':''}</p>`).join('')}<small>${esc(x.explain)}</small></div>`).join('')}<button class="btn" onclick="A.close()">닫기</button>`;
const A=window.A={go:wrap(go),close:()=>$('#modal').innerHTML='',
  login:wrap(async()=>{await signInWithPopup(fb.auth,new GoogleAuthProvider())}),
  logout:wrap(async()=>{await signOut(fb.auth)}),
  set:(k,v)=>{set[k]=v;saveSet();if(['bg','theme'].includes(k))go('settings')},
  av:n=>{draft.avatar=n;draft.photoURL='';go('profile',{keep:1})},goal:t=>{draft.goal=t.trim();go('profile',{keep:1})},
  nophoto:()=>{draft.photoURL='';go('profile',{keep:1})},
  photo:wrap(async f=>{if(!f)return;$('#bigav').innerHTML=`<img src="${URL.createObjectURL(f)}">`;try{draft.photoURL=await upload(f,`profiles/${U.uid}/${Date.now()}`);toast('프로필 사진을 올렸어요.')}catch(e){draft.photoURL=me?.photoURL||'';throw e}finally{go('profile',{keep:1})}}),
  saveProfile:wrap(async()=>{const nick=draft.nick.trim();if(!nick)return toast('닉네임을 입력해 주세요.');
    const d={nickname:nick,avatar:draft.avatar,photoURL:draft.photoURL||'',goal:draft.goal||''};
    if(me)await updateDoc(doc(fb.db,'users',U.uid),d);else await setDoc(doc(fb.db,'users',U.uid),{...d,points:0,rating:0,quizzesDone:0,createdAt:serverTimestamp(),settings:set});
    await refreshMe();toast('프로필을 저장했어요.');go('home')}),
  memo:wrap(async id=>{const m=memos[id],l=await getDoc(doc(fb.db,'treeMemos',id,'likes',U.uid));
    modal(`<div class="row"><span class="chip">${ORN[m.ornament]||'🔔'} ${esc(m.ornament)}</span><button class="back" onclick="A.close()">✕</button></div><div class="row" style="justify-content:flex-start;margin:10px 0"><span class="av">${avatar(m)}</span><b>${esc(m.nickname)}</b></div>${m.bookTitle?`<small>《${esc(m.bookTitle)}》</small>`:''}<h2>${esc(m.title)}</h2><p>${md(m.content)}</p><button id="lk" class="btn ${l.exists()?'dis':''}" onclick="A.like('${id}')">❤️ 공감 <b id="lc">${m.likes||0}</b></button>`)}),
  like:wrap(async id=>{const mr=doc(fb.db,'treeMemos',id),lr=doc(mr,'likes',U.uid);
    try{await runTransaction(fb.db,async t=>{if((await t.get(lr)).exists())throw Error('dup');t.set(lr,{at:serverTimestamp()});t.update(mr,{likes:increment(1)})})}catch(e){if(e.message==='dup')return toast('이미 공감한 메모예요.');throw e}
    memos[id].likes=(memos[id].likes||0)+1;$('#lc').textContent=memos[id].likes;$('#lk').classList.add('dis');sfx('like')}),
  write:wrap(async()=>{await loadQuizzes();wd={orn:'황금 종'};
    modal(`<div class="row"><h2 style="margin:0">트리에 메모 걸기</h2><button class="back" onclick="A.close()">✕</button></div><label>오너먼트 모양</label><div class="ornpick">${Object.entries(ORN).map(([n,e])=>`<button class="${n===wd.orn?'on':''}" onclick="A.orn(this,'${n}')">${e}<small>${n}</small></button>`).join('')}</div>
<label>연관 도서 <small>선택</small></label><select id="mb"><option value="">선택 안 함</option>${Object.values(quizzes).map(q=>`<option>${esc(q.bookTitle)}</option>`).join('')}</select>
<label>메모 제목 <span id="tc">0 / 30</span></label><input id="mt" maxlength="30" oninput="A.pv()"><label>남길 이야기 &amp; 문장 <span id="cc">0 / 300</span></label><textarea id="mc" maxlength="300" oninput="A.pv()"></textarea>
<div class="card" id="pv"><small>오너먼트 미리보기</small></div><div class="row"><span>서재 트리에 전체 공개</span><span class="sw"><input type="checkbox" id="mp" checked></span></div><small>메모를 걸면 살롱 포인트 +30P가 적립돼요.</small>
<div class="row" style="margin-top:12px"><button class="btn gh" onclick="A.close()">취소</button><button class="btn" onclick="A.post()">트리에 걸기 (+30P)</button></div>`)}),
  orn:(b,n)=>{wd.orn=n;document.querySelectorAll('.ornpick button').forEach(x=>x.classList.toggle('on',x===b));A.pv()},
  pv:()=>{$('#tc').textContent=`${$('#mt').value.length} / 30`;$('#cc').textContent=`${$('#mc').value.length} / 300`;$('#pv').innerHTML=`<small>오너먼트 미리보기 · ${esc(me.nickname)}</small><br>${ORN[wd.orn]} <b>${esc($('#mt').value)}</b><br><small>${esc($('#mc').value.slice(0,60))}</small>`},
  post:wrap(async()=>{const t=$('#mt').value.trim(),c=$('#mc').value.trim();if(!t||!c)return toast('제목과 내용을 입력해 주세요.');
    const r=await addDoc(collection(fb.db,'treeMemos'),{uid:U.uid,nickname:me.nickname,avatar:me.avatar,photoURL:me.photoURL||'',bookTitle:$('#mb').value,title:t,content:c,ornament:wd.orn,likes:0,public:$('#mp').checked,createdAt:serverTimestamp()});
    let msg='트리에 메모를 걸었어요!';try{const s=await api('/api/score',{action:'memo',memoId:r.id});if(s.points)msg+=` +${s.points}P`;await refreshMe()}catch(e){msg+=' (포인트 적립은 실패했어요)'}
    A.close();toast(msg);sfx('correct');go(V)}),
  ask:wrap(async t=>{const i=$('#si');t=(t||i.value).trim();if(!t||busy)return;busy=true;i.value='';const box=$('#chat');chat.push({role:'user',text:t});box.insertAdjacentHTML('beforeend',bub(chat.at(-1))+'<div class="bub dots" id="ty">산타가 생각하는 중</div>');box.lastElementChild.scrollIntoView();
    try{const r=await api('/api/generate',{messages:chat,book:$('#sb').value});chat.push({role:'model',text:r.text});$('#ty').outerHTML=bub(chat.at(-1));
      await setDoc(doc(fb.db,'santaChats',U.uid),{uid:U.uid,messages:chat.slice(-40),updatedAt:serverTimestamp()})}
    catch(e){chat.pop();$('#ty')?.remove();toast(err(e))}finally{busy=false}}),
  reset:wrap(async()=>{await setDoc(doc(fb.db,'santaChats',U.uid),{uid:U.uid,messages:[],updatedAt:serverTimestamp()});go('santa')}),
  pick:wrap(async k=>{if(busy)return;busy=true;const{q,i}=qz;document.querySelectorAll('.opt').forEach(b=>b.disabled=true);
    try{const r=await api('/api/score',{action:'answer',quizId:q.id,index:i,choice:k}),o=document.querySelectorAll('.opt');o[r.answer].classList.add('ok');if(!r.correct)o[k].classList.add('bad');
      me.points+=r.points;me.rating=Math.max(0,(me.rating||0)+r.rating);$('#pp').textContent=`⭐ ${me.points}P`;sfx(r.correct?'correct':'wrong');
      $('#fb').innerHTML=`<div class="card"><b>${r.correct?'✨ 정답입니다! 훌륭해요!':'아쉬워요, 오답이에요.'}</b><p class="pts">${r.points?`+${r.points}P · `:''}레이팅 ${r.rating>=0?'+':''}${r.rating}</p><p>${md(r.explain)}</p></div><button class="btn" onclick="A.go('${r.done?'result':'quiz'}',{id:'${q.id}'})">${r.done?'결과 보기':`다음 문제로 이동하기 (${i+2}/${r.total})`}</button>`;$('#fb').scrollIntoView({behavior:'smooth'})}
    catch(e){document.querySelectorAll('.opt').forEach(b=>b.disabled=false);throw e}finally{busy=false}}),
  /* 개발자 */
  s:(p,v)=>{const k=p.split('.');let o=D;while(k.length>1)o=o[k.shift()];o[k[0]]=v},
  cover:wrap(async f=>{if(!f)return;D.cover=await upload(f,`covers/${Date.now()}`);toast('표지를 올렸어요.');go('devStudio',{keep:1})}),
  addq:()=>{D.q.push(blank());go('devStudio',{keep:1})},rmq:i=>{D.q.splice(i,1);go('devStudio',{keep:1})},
  tag:t=>{t=t.replace('✓ ','').trim();D.tags=D.tags.includes(t)?D.tags.filter(x=>x!==t):[...D.tags,t];go('devStudio',{keep:1})},
  newtag:()=>{const t=$('#nt').value.trim();if(t&&!D.tags.includes(t))D.tags.push(t);go('devStudio',{keep:1})},
  prevDraft:()=>modal(prevHTML(D.title||D.book,D.q)),
  prevSaved:wrap(async id=>{const k=await getDoc(doc(fb.db,'quizzes',id,'keys','answers')),ks=k.exists()?k.data().answers:[],q=quizzes[id];modal(prevHTML(q.bookTitle,q.questions.map((x,i)=>({...x,o:x.options,a:ks[i]?.a,explain:ks[i]?.explain||''}))))}),
  askPub:()=>{const e=A.check();if(e)return toast(e);modal(`<h2>퀴즈를 학생들에게 공개하시겠습니까?</h2><p>《${esc(D.book)}》 ${D.q.length}문항이 독서 퀴즈 목록에 바로 노출돼요.</p><div class="row"><button class="btn gh" onclick="A.close()">취소</button><button class="btn" onclick="A.saveQ('published')">공개하기</button></div>`)},
  check:()=>{if(!D.book.trim()||!D.title.trim())return'도서 제목과 퀴즈 팩 제목을 입력해 주세요.';for(const[i,x]of D.q.entries()){if(!x.prompt.trim()||x.o.some(o=>!o.trim()))return`${i+1}번 문항의 지문과 선택지 5개를 모두 입력해 주세요.`;if(x.a<0)return`${i+1}번 문항의 정답을 선택해 주세요.`}return''},
  saveQ:wrap(async st=>{if(st==='published'){const e=A.check();if(e)return toast(e)}else if(!D.book.trim())return toast('임시저장하려면 도서 제목이 필요해요.');
    const id=D.id||doc(collection(fb.db,'quizzes')).id,data={bookTitle:D.book.trim(),author:D.author,translator:D.trans,isbn:D.isbn,description:D.desc,coverUrl:D.cover,title:D.title,difficulty:D.diff,audience:D.aud,tags:D.tags,status:st,count:D.q.length,questions:D.q.map(x=>({prompt:x.prompt,excerpt:x.excerpt,options:x.o,pts:x.pts||20})),updatedAt:serverTimestamp(),...(D.id?{}:{createdAt:serverTimestamp()})};
    await setDoc(doc(fb.db,'quizzes',id),data,{merge:true});await setDoc(doc(fb.db,'quizzes',id,'keys','answers'),{answers:D.q.map(x=>({a:x.a,explain:x.explain}))});
    D.id=id;D.status=st;logDev(st==='published'?'공개':'임시저장',D.book);A.close();toast(st==='published'?'새로운 독서 퀴즈가 공개되었습니다!':'임시 저장했어요. (학생에게는 보이지 않아요)');go('devStudio',{id,keep:1})}),
  tog:wrap(async(id,on)=>{await updateDoc(doc(fb.db,'quizzes',id),{status:on?'published':'draft'});logDev(on?'공개':'비공개',quizzes[id].bookTitle);toast(on?'학생에게 공개했어요.':'비공개로 전환했어요.');go('devManage',P)}),
  del:id=>{const q=quizzes[id];modal(`<h2>퀴즈 삭제</h2><p>《${esc(q.bookTitle)}》 퀴즈와 <b>학생 풀이 기록·통계</b>가 영구 삭제돼요. 이미 지급된 포인트·레이팅은 유지돼요.</p><small>확인을 위해 도서 제목을 입력해 주세요.</small><input id="dc" oninput="$('#dg').disabled=this.value.trim()!==${JSON.stringify(q.bookTitle).replace(/"/g,'&quot;')}"><div class="row"><button class="btn gh" onclick="A.close()">취소</button><button class="btn" id="dg" disabled onclick="A.delGo('${id}')">영구 삭제</button></div>`)},
  delGo:wrap(async id=>{const t=quizzes[id].bookTitle,as=await getDocs(query(collection(fb.db,'quizAttempts'),where('quizId','==',id)));await Promise.all(as.docs.map(d=>deleteDoc(d.ref)));
    await deleteDoc(doc(fb.db,'quizzes',id,'keys','answers'));await deleteDoc(doc(fb.db,'quizzes',id));logDev('삭제',t);A.close();toast('퀴즈를 삭제했어요.');go('devManage',P)})};
window.$=$;window.draft_nick=v=>{draft.nick=v;$('#nc').textContent=`${v.length} / 12`};

/* ---------- 스와이프 (입력창·모달 제외) ---------- */
let sx,sy;addEventListener('touchstart',e=>{sx=e.touches[0].clientX;sy=e.touches[0].clientY},{passive:true});
addEventListener('touchend',e=>{if(e.target.closest('input,textarea,select,.ov')||$('#modal').firstChild)return;const dx=e.changedTouches[0].clientX-sx,dy=e.changedTouches[0].clientY-sy;if(Math.abs(dx)<70||Math.abs(dy)>50)return;
  if(V==='home'&&dx<0)go('quizzes');else if(V==='quizzes'&&dx>0)go('ranking');else if(V==='ranking'&&dx<0)go('quizzes')},{passive:true});

/* ---------- 시작 ---------- */
apply();
if(configured)onAuthStateChanged(fb.auth,async u=>{try{U=u;if(!u){me=null;return go('login')}
  const s=await getDoc(doc(fb.db,'users',u.uid));me=s.exists()?s.data():null;
  if(me?.settings){set={...set,...me.settings};localStorage.ms=JSON.stringify(set);apply()}go(me?'home':'profile')}catch(e){console.error(e);toast(err(e));go('login')}});
else go('login');
