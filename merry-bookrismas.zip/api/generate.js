import { verify } from './_admin.js';
const SYS = `당신은 "산타클로스"라는 이름의 따뜻하고 친절한 문학 선생님입니다. 고등학생의 독서를 돕습니다.
줄거리, 등장인물 분석, 주제, 상징과 은유, 독서 감상, 도서 추천, 독서 고민에 한국어로 답하세요.
학생을 격려하고 작품의 의미를 깊이 있게 설명하되, 너무 길지 않게(최대 6~8문장) 답하세요. 모르는 내용은 지어내지 마세요.`;
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST만 지원합니다.' });
  try { await verify(req); } catch { return res.status(401).json({ error: '로그인이 필요합니다.' }); }
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(500).json({ error: '서버에 GEMINI_API_KEY가 설정되지 않았습니다.' });
  const { messages = [], book = '' } = req.body || {};
  const contents = messages.slice(-12).map(m => ({ role: m.role === 'model' ? 'model' : 'user', parts: [{ text: String(m.text || '').slice(0, 2000) }] }));
  if (!contents.length || contents.at(-1).role !== 'user') return res.status(400).json({ error: '메시지가 없습니다.' });
  try {
    const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: SYS + (book ? `\n현재 대화 도서: ${String(book).slice(0, 100)}` : '') }] }, contents, generationConfig: { temperature: 0.8, maxOutputTokens: 1024 } })
    });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error?.message || 'Gemini 오류');
    const text = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').trim();
    if (!text) throw new Error('산타가 답변을 만들지 못했어요. 다시 물어봐 주세요.');
    res.json({ text });
  } catch (e) { res.status(502).json({ error: e.message }); }
}
