// 점수/레이팅은 오직 이 서버 함수(Admin SDK)만 변경합니다. 규칙: 정답 +문항배점(기본 20)P·+200 레이팅 / 오답 포인트 0·-100 레이팅
import { db, admin, verify } from './_admin.js';
const FV = admin.firestore.FieldValue;
export default async function handler(req, res) {
  try {
    if (req.method !== 'POST') return res.status(405).json({ error: 'POST만 지원합니다.' });
    const u = await verify(req).catch(() => null);
    if (!u) return res.status(401).json({ error: '로그인이 필요합니다.' });
    const { action, quizId, index, choice, memoId } = req.body || {};
    const uref = db.doc('users/' + u.uid);
    if (action === 'memo') {
      const mr = db.doc('treeMemos/' + String(memoId));
      return res.json(await db.runTransaction(async t => {
        const [m, us] = await Promise.all([t.get(mr), t.get(uref)]);
        if (!m.exists || m.data().uid !== u.uid || !us.exists) throw new Error('유효하지 않은 메모입니다.');
        if (m.data().awarded) return { points: 0 };
        t.update(mr, { awarded: true }); t.update(uref, { points: FV.increment(30) });
        return { points: 30 };
      }));
    }
    if (action === 'answer') {
      const aref = db.doc(`quizAttempts/${u.uid}_${quizId}`);
      return res.json(await db.runTransaction(async t => {
        const [a, qs, ks, us] = await Promise.all([t.get(aref), t.get(db.doc('quizzes/' + quizId)), t.get(db.doc(`quizzes/${quizId}/keys/answers`)), t.get(uref)]);
        if (!qs.exists || qs.data().status !== 'published' || !ks.exists || !us.exists) throw new Error('퀴즈를 찾을 수 없습니다.');
        const q = qs.data(), n = q.questions.length, i = Number(index), c = Number(choice);
        if (!Number.isInteger(i) || i < 0 || i >= n || !Number.isInteger(c) || c < 0 || c > 4) throw new Error('잘못된 요청입니다.');
        const prev = a.exists ? (a.data().answers || {}) : {}, cnt = Object.keys(prev).length;
        if (prev[i]) return { ...prev[i], dup: true, done: cnt >= n, total: n };   // 중복 제출은 점수 없음
        if (i !== cnt) throw new Error('문제를 순서대로 풀어주세요.');
        const k = ks.data().answers[i], ok = c === k.a, pts = ok ? (q.questions[i].pts || 20) : 0;
        const before = us.data().rating || 0, delta = Math.max(0, before + (ok ? 200 : -100)) - before;
        const ans = { choice: c, correct: ok, answer: k.a, explain: k.explain || '', points: pts, rating: delta };
        const done = i + 1 >= n;
        t.set(aref, { uid: u.uid, quizId, answers: { [i]: ans }, correctCount: FV.increment(ok ? 1 : 0), earnedPoints: FV.increment(pts), ratingChange: FV.increment(delta),
          ...(a.exists ? {} : { startedAt: FV.serverTimestamp() }), ...(done ? { completedAt: FV.serverTimestamp() } : {}) }, { merge: true });
        t.update(uref, { points: FV.increment(pts), rating: FV.increment(delta), ...(done ? { quizzesDone: FV.increment(1) } : {}) });
        return { ...ans, done, total: n };
      }));
    }
    res.status(400).json({ error: '알 수 없는 요청입니다.' });
  } catch (e) { res.status(400).json({ error: e.message }); }
}
