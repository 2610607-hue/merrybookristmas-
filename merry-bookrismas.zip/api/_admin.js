import admin from 'firebase-admin';
if (!admin.apps.length) {
  admin.initializeApp({ credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT)) });
}
export { admin };
export const db = admin.firestore();
export const verify = (req) => admin.auth().verifyIdToken((req.headers.authorization || '').replace('Bearer ', ''));
