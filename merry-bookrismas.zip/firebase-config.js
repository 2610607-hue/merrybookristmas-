// Firebase 콘솔 > 프로젝트 설정 > 내 앱(웹)의 값을 입력하세요. (이 값은 공개되어도 되는 웹 설정입니다)
export const firebaseConfig = {
  apiKey: "",
  authDomain: "merrybookristmas.firebaseapp.com",
  projectId: "",
  storageBucket: "",        // 비워두면 이미지 업로드는 "저장소 미설정" 오류를 표시합니다
  messagingSenderId: "",
  appId: ""
};
export const DEVELOPERS = ["lazymin99@gmail.com", "2610607@sw.hs.kr"];
